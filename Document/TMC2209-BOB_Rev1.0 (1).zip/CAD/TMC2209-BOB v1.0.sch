EESchema Schematic File Version 4
LIBS:TMC2209-BOB v1.0-cache
EELAYER 29 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title "TMC2209-BOB"
Date ""
Rev "1.0"
Comp "Trinamic OÜ"
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C107
U 1 1 5C533DAB
P 4600 2400
F 0 "C107" H 4600 2550 39  0000 C CNN
F 1 "22nF/50V/0805" H 4600 2250 39  0000 C CNN
F 2 "Capacitor_SMD:C_0805_2012Metric" V 4750 2438 50  0001 C CNN
F 3 "~" V 4600 2400 50  0001 C CNN
	1    4600 2400
	1    0    0    -1  
$EndComp
Wire Wire Line
	5200 2550 4900 2550
Wire Wire Line
	4900 2550 4900 2600
Wire Wire Line
	4900 2600 4300 2600
Wire Wire Line
	4300 2600 4300 2400
Wire Wire Line
	4300 2400 4450 2400
Wire Wire Line
	4750 2400 4900 2400
Wire Wire Line
	4900 2400 4900 2450
Wire Wire Line
	4900 2450 5200 2450
Wire Wire Line
	5100 3250 5200 3250
Wire Wire Line
	4100 2950 5200 2950
Wire Wire Line
	4100 2950 4100 2800
Connection ~ 4100 2950
Wire Wire Line
	4100 2800 3600 2800
Wire Wire Line
	3700 2950 3600 2950
Wire Wire Line
	4000 2950 4100 2950
$Comp
L TMC2209-BOB-v1.0-rescue:R-Device R102
U 1 1 5C543558
P 3850 2950
F 0 "R102" H 3850 3050 39  0000 C CNN
F 1 "1kΩ/1%/0603" H 3850 2850 39  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 3850 2880 50  0001 C CNN
F 3 "~" V 3850 2950 50  0001 C CNN
	1    3850 2950
	1    0    0    -1  
$EndComp
Wire Wire Line
	5850 2250 5850 2150
Wire Wire Line
	5750 2150 5750 2250
$Comp
L Trinamic:TMC2209 IC101
U 1 1 5C505AA3
P 5750 3050
F 0 "IC101" H 5750 3100 40  0000 C CNN
F 1 "TMC2209" H 5750 3000 40  0000 C CNN
F 2 "Trinamic:QFN28P" H 5750 3875 60  0001 C CNN
F 3 "" H 5750 3975 60  0001 C CNN
	1    5750 3050
	1    0    0    -1  
$EndComp
Wire Wire Line
	5650 2150 5650 2250
Wire Wire Line
	5750 2150 5650 2150
Wire Wire Line
	5850 2150 6300 2150
Wire Wire Line
	6300 2150 6300 1500
Wire Wire Line
	6300 1500 6100 1500
Wire Wire Line
	5800 1500 5650 1500
Connection ~ 5650 2150
Wire Wire Line
	5650 1500 5650 2150
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C106
U 1 1 5C54B44D
P 5950 1500
F 0 "C106" H 5950 1650 39  0000 C CNN
F 1 "100nF/50V/0603" H 5950 1350 39  0000 C CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" V 6100 1538 50  0001 C CNN
F 3 "~" V 5950 1500 50  0001 C CNN
	1    5950 1500
	1    0    0    -1  
$EndComp
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C108
U 1 1 5C558489
P 4650 4050
F 0 "C108" H 4650 4200 39  0000 C CNN
F 1 "100nF/50V/0603" H 4650 3900 39  0000 C CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" V 4800 4088 50  0001 C CNN
F 3 "~" V 4650 4050 50  0001 C CNN
	1    4650 4050
	0    -1   -1   0   
$EndComp
Wire Wire Line
	4650 3650 4650 3900
Wire Wire Line
	4650 4200 4650 4300
Wire Wire Line
	5850 3850 5850 3950
Wire Wire Line
	5850 3950 5750 3950
Wire Wire Line
	5650 3950 5650 3850
Wire Wire Line
	5750 3850 5750 3950
Connection ~ 5750 3950
Wire Wire Line
	5750 3950 5650 3950
Wire Wire Line
	5750 4300 5750 3950
$Comp
L power:GND #PWR0101
U 1 1 5C55AD04
P 4650 4300
F 0 "#PWR0101" H 4650 4050 39  0001 C CNN
F 1 "GND" H 4650 4150 39  0000 C CNN
F 2 "" H 4650 4300 50  0001 C CNN
F 3 "" H 4650 4300 50  0001 C CNN
	1    4650 4300
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR0102
U 1 1 5C55B252
P 5750 4300
F 0 "#PWR0102" H 5750 4050 39  0001 C CNN
F 1 "GND" H 5750 4150 39  0000 C CNN
F 2 "" H 5750 4300 50  0001 C CNN
F 3 "" H 5750 4300 50  0001 C CNN
	1    5750 4300
	1    0    0    -1  
$EndComp
NoConn ~ 6300 3550
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C109
U 1 1 5C55C07B
P 6500 4050
F 0 "C109" H 6500 4200 39  0000 C CNN
F 1 "2,2µF/50V/0603" H 6500 3900 39  0000 C CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" V 6650 4088 50  0001 C CNN
F 3 "~" V 6500 4050 50  0001 C CNN
	1    6500 4050
	0    -1   -1   0   
$EndComp
Wire Wire Line
	6500 3900 6500 3450
Wire Wire Line
	6500 3450 6300 3450
Wire Wire Line
	6500 4200 6500 4300
$Comp
L power:GND #PWR0103
U 1 1 5C55DA1D
P 6500 4300
F 0 "#PWR0103" H 6500 4050 39  0001 C CNN
F 1 "GND" H 6500 4150 39  0000 C CNN
F 2 "" H 6500 4300 50  0001 C CNN
F 3 "" H 6500 4300 50  0001 C CNN
	1    6500 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	6300 2850 8100 2850
$Comp
L TMC2209-BOB-v1.0-rescue:R-Device R104
U 1 1 5C57673E
P 8100 3350
F 0 "R104" H 8100 3450 39  0000 C CNN
F 1 "120mΩ/1W/2010" H 8100 3250 39  0000 C CNN
F 2 "Resistor_SMD:R_2010_5025Metric" H 8100 3280 50  0001 C CNN
F 3 "~" V 8100 3350 50  0001 C CNN
	1    8100 3350
	0    -1   -1   0   
$EndComp
$Comp
L power:GND #PWR0105
U 1 1 5C57B7F1
P 8100 3750
F 0 "#PWR0105" H 8100 3500 39  0001 C CNN
F 1 "GND" H 8100 3600 39  0000 C CNN
F 2 "" H 8100 3750 50  0001 C CNN
F 3 "" H 8100 3750 50  0001 C CNN
	1    8100 3750
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR0107
U 1 1 5C588016
P 3150 2250
F 0 "#PWR0107" H 3150 2000 39  0001 C CNN
F 1 "GND" H 3150 2100 39  0000 C CNN
F 2 "" H 3150 2250 50  0001 C CNN
F 3 "" H 3150 2250 50  0001 C CNN
	1    3150 2250
	1    0    0    -1  
$EndComp
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C103
U 1 1 5C5938CA
P 4050 1500
F 0 "C103" H 4050 1650 39  0000 C CNN
F 1 "100nF/50V/0603" H 4050 1350 39  0000 C CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" V 4200 1538 50  0001 C CNN
F 3 "~" V 4050 1500 50  0001 C CNN
	1    4050 1500
	0    -1   -1   0   
$EndComp
Wire Wire Line
	5000 1350 5000 1150
Wire Wire Line
	5000 1150 5650 1150
Wire Wire Line
	4050 1350 4050 1150
Connection ~ 4050 1150
Wire Wire Line
	4050 1150 4500 1150
Wire Wire Line
	3600 1350 3600 1150
Wire Wire Line
	3600 1150 4050 1150
Wire Wire Line
	5000 1650 5000 1750
Wire Wire Line
	3600 1650 3600 2150
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C101
U 1 1 5C5B9986
P 3150 1500
F 0 "C101" H 3150 1650 39  0000 C CNN
F 1 "10µF/50V/1210" H 3150 1350 39  0000 C CNN
F 2 "Capacitor_SMD:C_1210_3225Metric" V 3300 1538 50  0001 C CNN
F 3 "~" V 3150 1500 50  0001 C CNN
	1    3150 1500
	0    -1   -1   0   
$EndComp
Connection ~ 3600 1150
Wire Wire Line
	3150 1350 3150 1150
Wire Wire Line
	3150 1150 3600 1150
Wire Wire Line
	3150 1650 3150 2150
$Comp
L TMC2209-BOB-v1.0-rescue:R-Device R101
U 1 1 5C5CD362
P 5000 1900
F 0 "R101" H 5000 2000 39  0000 C CNN
F 1 "1100mΩ/1%/0603" H 5000 1800 39  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 5000 1830 50  0001 C CNN
F 3 "~" V 5000 1900 50  0001 C CNN
	1    5000 1900
	0    -1   -1   0   
$EndComp
Wire Wire Line
	3150 2150 3600 2150
Connection ~ 3600 2150
Wire Wire Line
	3600 2150 4050 2150
Connection ~ 4050 2150
Wire Wire Line
	4050 2150 4500 2150
Wire Wire Line
	5650 1150 5650 1500
Connection ~ 5650 1500
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C105
U 1 1 5C5C2068
P 5000 1500
F 0 "C105" H 5000 1650 39  0000 C CNN
F 1 "1µF/50V/0603" H 5000 1350 39  0000 C CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" V 5150 1538 50  0001 C CNN
F 3 "~" V 5000 1500 50  0001 C CNN
	1    5000 1500
	0    -1   -1   0   
$EndComp
$Comp
L Device:LED D102
U 1 1 5C810BDA
P 7500 3200
F 0 "D102" H 7500 3100 39  0000 C CNN
F 1 "white/0603" H 7500 3300 39  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric_Castellated" H 7500 3200 50  0001 C CNN
F 3 "https://media.digikey.com/pdf/Data%20Sheets/Everlight%20PDFs/19-117Z-T1D-CN1P2B3X-3T.pdf" H 7500 3200 50  0001 C CNN
F 4 "1080-1574-1-ND" H 7500 3200 50  0001 C CNN "Digi-Key part number"
	1    7500 3200
	-1   0    0    1   
$EndComp
$Comp
L TMC2209-BOB-v1.0-rescue:R-Device R103
U 1 1 5C8118BB
P 7000 3200
F 0 "R103" H 7000 3300 39  0000 C CNN
F 1 "220Ω/1%/0603" H 7000 3100 39  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 7000 3130 50  0001 C CNN
F 3 "~" V 7000 3200 50  0001 C CNN
	1    7000 3200
	1    0    0    -1  
$EndComp
Wire Wire Line
	7150 3200 7350 3200
Wire Wire Line
	7650 3200 7800 3200
Wire Wire Line
	7800 3200 7800 3750
$Comp
L power:GND #PWR0109
U 1 1 5C81DF79
P 7800 3750
F 0 "#PWR0109" H 7800 3500 39  0001 C CNN
F 1 "GND" H 7800 3600 39  0000 C CNN
F 2 "" H 7800 3750 50  0001 C CNN
F 3 "" H 7800 3750 50  0001 C CNN
	1    7800 3750
	1    0    0    -1  
$EndComp
$Comp
L TMC2209-BOB-v1.0-rescue:R-Device R106
U 1 1 5C529126
P 5100 4050
F 0 "R106" H 5100 4150 39  0000 C CNN
F 1 "100kΩ/1%/0603" H 5100 3950 39  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 5100 3980 50  0001 C CNN
F 3 "~" V 5100 4050 50  0001 C CNN
	1    5100 4050
	0    -1   -1   0   
$EndComp
Wire Wire Line
	5100 3350 5200 3350
Wire Wire Line
	5200 3550 5100 3550
$Comp
L power:GND #PWR0111
U 1 1 5C55B432
P 5100 4300
F 0 "#PWR0111" H 5100 4050 39  0001 C CNN
F 1 "GND" H 5100 4150 39  0000 C CNN
F 2 "" H 5100 4300 50  0001 C CNN
F 3 "" H 5100 4300 50  0001 C CNN
	1    5100 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	5100 4300 5100 4200
Wire Wire Line
	5100 3900 5100 3550
Text HLabel 3050 1150 0    39   Input ~ 0
+VM
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C102
U 1 1 5C6A8332
P 3600 1500
F 0 "C102" H 3600 1650 39  0000 C CNN
F 1 "10µF/50V/1210" H 3600 1350 39  0000 C CNN
F 2 "Capacitor_SMD:C_1210_3225Metric" V 3750 1538 50  0001 C CNN
F 3 "~" V 3600 1500 50  0001 C CNN
	1    3600 1500
	0    -1   -1   0   
$EndComp
Wire Wire Line
	5000 2050 5000 2150
Wire Wire Line
	4050 1650 4050 2150
$Comp
L TMC2209-BOB-v1.0-rescue:C-Device C104
U 1 1 5C80316A
P 4500 1500
F 0 "C104" H 4500 1650 39  0000 C CNN
F 1 "100nF/50V/0603" H 4500 1350 39  0000 C CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" V 4650 1538 50  0001 C CNN
F 3 "~" V 4500 1500 50  0001 C CNN
	1    4500 1500
	0    -1   -1   0   
$EndComp
Wire Wire Line
	4500 1150 4500 1350
Wire Wire Line
	4500 1650 4500 2150
Wire Wire Line
	5000 2150 4500 2150
Wire Wire Line
	5000 1150 4500 1150
Connection ~ 5000 1150
Connection ~ 4500 1150
Connection ~ 4500 2150
Wire Wire Line
	5100 2850 5200 2850
Wire Wire Line
	5100 2750 5200 2750
Wire Wire Line
	5100 2650 5200 2650
Text Label 5100 2650 2    39   ~ 0
V_ref
Wire Wire Line
	6300 2750 7600 2750
Wire Wire Line
	6300 2650 7600 2650
Wire Wire Line
	6300 2550 7600 2550
Wire Wire Line
	6300 2450 7600 2450
$Comp
L Connector:Conn_01x10_Male J102
U 1 1 5C8B16B6
P 2650 6150
F 0 "J102" H 2800 6800 50  0000 C CNN
F 1 "Conn_01x10_Male" H 2800 6700 50  0000 C CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x10_P2.54mm_Vertical" H 2650 6150 50  0001 C CNN
F 3 "~" H 2650 6150 50  0001 C CNN
	1    2650 6150
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_01x10_Male J101
U 1 1 5C8B21DF
P 2050 6150
F 0 "J101" H 2200 6800 50  0000 C CNN
F 1 "Conn_01x10_Male" H 2200 6700 50  0000 C CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x10_P2.54mm_Vertical" H 2050 6150 50  0001 C CNN
F 3 "~" H 2050 6150 50  0001 C CNN
	1    2050 6150
	-1   0    0    -1  
$EndComp
Connection ~ 3150 1150
Connection ~ 3150 2150
Wire Wire Line
	5100 3450 5200 3450
Wire Wire Line
	8100 3500 8100 3750
Wire Wire Line
	8100 2850 8100 3200
Text Label 1850 5750 2    39   ~ 0
+Vcc_IO
$Comp
L power:GND #PWR0112
U 1 1 5C86A53A
P 1550 6850
F 0 "#PWR0112" H 1550 6600 39  0001 C CNN
F 1 "GND" H 1550 6700 39  0000 C CNN
F 2 "" H 1550 6850 50  0001 C CNN
F 3 "" H 1550 6850 50  0001 C CNN
	1    1550 6850
	1    0    0    -1  
$EndComp
Wire Wire Line
	1850 5850 1550 5850
Wire Wire Line
	1550 5850 1550 6250
Wire Wire Line
	1850 6250 1550 6250
Connection ~ 1550 6250
Wire Wire Line
	1550 6250 1550 6850
$Comp
L power:GND #PWR0113
U 1 1 5C872ACD
P 3150 6850
F 0 "#PWR0113" H 3150 6600 39  0001 C CNN
F 1 "GND" H 3150 6700 39  0000 C CNN
F 2 "" H 3150 6850 50  0001 C CNN
F 3 "" H 3150 6850 50  0001 C CNN
	1    3150 6850
	1    0    0    -1  
$EndComp
Wire Wire Line
	2850 6350 3150 6350
Wire Wire Line
	3150 6350 3150 6850
Wire Wire Line
	2850 5850 3150 5850
Wire Wire Line
	3150 5850 3150 6350
Connection ~ 3150 6350
Text Label 2850 5750 0    39   ~ 0
+VM
Text Label 2850 6050 0    39   ~ 0
B1
Text Label 2850 5950 0    39   ~ 0
B2
Text Label 2850 6150 0    39   ~ 0
A1
Text Label 2850 6250 0    39   ~ 0
A2
Text Label 2200 6900 3    39   ~ 0
DIAG
Text Label 5100 2750 2    39   ~ 0
ENN
Text Label 5100 2850 2    39   ~ 0
CLK16
Text Label 5100 3350 2    39   ~ 0
DIR
Text Label 5000 3650 2    39   ~ 0
+Vcc_IO
Text Label 7600 2450 0    39   ~ 0
A2
Text Label 7600 2550 0    39   ~ 0
A1
Text Label 7600 2650 0    39   ~ 0
B1
Text Label 7600 2750 0    39   ~ 0
B2
Text Label 1850 5950 2    39   ~ 0
UART_RX
Text Label 1850 6050 2    39   ~ 0
UART_TX
Text Label 3600 2950 2    39   ~ 0
UART_TX
Text Label 3600 2800 2    39   ~ 0
UART_RX
Text Notes 1400 5400 0    79   ~ 0
Board conections
Wire Notes Line
	1350 5250 1350 7100
Wire Notes Line
	1350 7100 3350 7100
Wire Notes Line
	3350 7100 3350 5250
Wire Notes Line
	3350 5250 1350 5250
Wire Wire Line
	8450 3500 8450 3750
Wire Wire Line
	8450 2950 8450 3200
$Comp
L power:GND #PWR0106
U 1 1 5C57C08A
P 8450 3750
F 0 "#PWR0106" H 8450 3500 39  0001 C CNN
F 1 "GND" H 8450 3600 39  0000 C CNN
F 2 "" H 8450 3750 50  0001 C CNN
F 3 "" H 8450 3750 50  0001 C CNN
	1    8450 3750
	1    0    0    -1  
$EndComp
$Comp
L TMC2209-BOB-v1.0-rescue:R-Device R105
U 1 1 5C5774A7
P 8450 3350
F 0 "R105" H 8450 3450 39  0000 C CNN
F 1 "120mΩ/1W/2010" H 8450 3250 39  0000 C CNN
F 2 "Resistor_SMD:R_2010_5025Metric" H 8450 3280 50  0001 C CNN
F 3 "~" V 8450 3350 50  0001 C CNN
	1    8450 3350
	0    -1   -1   0   
$EndComp
Wire Wire Line
	6300 2950 8450 2950
Wire Wire Line
	6400 3100 6300 3100
Text Label 6400 3200 0    39   ~ 0
DIAG
Wire Wire Line
	6300 3200 6850 3200
Text Label 6400 3100 0    39   ~ 0
index
Text Label 2100 6900 3    39   ~ 0
index
Text Label 1850 6150 2    39   ~ 0
V_ref
Text Label 2850 6450 0    39   ~ 0
MS1
Text Label 2850 6550 0    39   ~ 0
MS2
Text Label 2850 6650 0    39   ~ 0
SPREAD
Text Label 5100 3250 2    39   ~ 0
STEP
Wire Wire Line
	5100 3050 5200 3050
Text Label 5100 3050 2    39   ~ 0
MS1
Wire Wire Line
	5100 3150 5200 3150
Text Label 5100 3150 2    39   ~ 0
MS2
Text Label 5100 3450 2    39   ~ 0
SPREAD
$Comp
L TMC2209-BOB-v1.0-rescue:R-Device R107
U 1 1 5C8869B3
P 4300 3650
F 0 "R107" H 4300 3750 39  0000 C CNN
F 1 "1kΩ/1%/0603" H 4300 3550 39  0000 C CNN
F 2 "Resistor_SMD:R_0603_1608Metric" H 4300 3580 50  0001 C CNN
F 3 "~" V 4300 3650 50  0001 C CNN
	1    4300 3650
	1    0    0    -1  
$EndComp
$Comp
L Device:LED D104
U 1 1 5C886E59
P 3800 3650
F 0 "D104" H 3800 3550 39  0000 C CNN
F 1 "blue/0603" H 3800 3750 39  0000 C CNN
F 2 "LED_SMD:LED_0603_1608Metric_Castellated" H 3800 3650 50  0001 C CNN
F 3 "http://optoelectronics.liteon.com/upload/download/DS22-2003-020/LTST-C191TBKT-5A.pdf" H 3800 3650 50  0001 C CNN
F 4 "160-2212-1-ND" H 3800 3650 50  0001 C CNN "Digi-Key part number"
	1    3800 3650
	1    0    0    1   
$EndComp
Wire Wire Line
	4450 3650 4650 3650
Connection ~ 4650 3650
Wire Wire Line
	4650 3650 5200 3650
Wire Wire Line
	4150 3650 3950 3650
Wire Wire Line
	3650 3650 3550 3650
Wire Wire Line
	3550 3650 3550 4300
$Comp
L power:GND #PWR0108
U 1 1 5C89E4D7
P 3550 4300
F 0 "#PWR0108" H 3550 4050 39  0001 C CNN
F 1 "GND" H 3550 4150 39  0000 C CNN
F 2 "" H 3550 4300 50  0001 C CNN
F 3 "" H 3550 4300 50  0001 C CNN
	1    3550 4300
	1    0    0    -1  
$EndComp
Wire Wire Line
	3050 1150 3150 1150
Wire Wire Line
	3150 2150 3150 2250
Text Label 1850 6350 2    39   ~ 0
CLK16
Text Label 1850 6450 2    39   ~ 0
ENN
Text Label 1850 6550 2    39   ~ 0
STEP
Text Label 1850 6650 2    39   ~ 0
DIR
$Comp
L Connector:Conn_01x02_Male J103
U 1 1 5C8DC918
P 2100 6700
F 0 "J103" V 2150 6500 39  0000 R CNN
F 1 "Conn_01x02_Male" V 2200 6500 39  0000 R CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical" H 2100 6700 50  0001 C CNN
F 3 "~" H 2100 6700 50  0001 C CNN
	1    2100 6700
	0    -1   1    0   
$EndComp
$EndSCHEMATC
